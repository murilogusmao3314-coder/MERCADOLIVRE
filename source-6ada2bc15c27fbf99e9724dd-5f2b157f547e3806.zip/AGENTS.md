<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

## Project rules

- The site is a static mirror under `public/site/`, shown at `/` through a full-screen iframe — keeps its relative links working without rewriting the pages.
- Do not read or summarize the content of `public/site/` beyond the exact lines a requested change needs — the owner marked it private.
