import { createFileRoute } from "@tanstack/react-router";

/**
 * Home: displays the user's static site (served from /public/site) in a
 * full-screen frame so its own relative links keep working unchanged.
 */
const SITE_ENTRY = "/site/app.ultimaetapalivre.site/index.html";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Mquel" },
      { name: "description", content: "Visualização do site Mquel." },
      { property: "og:title", content: "Mquel" },
      { property: "og:description", content: "Visualização do site Mquel." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex, nofollow" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <iframe
      src={SITE_ENTRY}
      title="Mquel"
      className="fixed inset-0 h-screen w-screen border-0 bg-background"
    />
  );
}
