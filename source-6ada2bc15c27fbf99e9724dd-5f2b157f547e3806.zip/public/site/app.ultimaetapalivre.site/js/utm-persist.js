(function(){
  function mergeSearch(href){
    try{
      var u=new URL(href, location.origin);
      if(u.origin!==location.origin) return href;
      var src=new URLSearchParams(location.search);
      src.forEach(function(v,k){ if(!u.searchParams.has(k)) u.searchParams.append(k,v); });
      return u.pathname+u.search+u.hash;
    }catch(e){ return href; }
  }
  document.addEventListener('click', function(e){
    var a=e.target.closest && e.target.closest('a[href]');
    if(!a) return;
    var href=a.getAttribute('href');
    if(!href || /^(#|mailto:|tel:|javascript:)/i.test(href)) return;
    a.setAttribute('href', mergeSearch(href));
  }, true);
})();
